const pool = require('../db');
const service = require('../services/responseService');
const emailService = require('../services/emailService');

exports.createResponse = async (req, res, next) => {
  const eventId = +req.params.eventId;
  const conn = await pool.getConnection();

  try {
    // 1) Load event + live counters
    const [[event]] = await conn.query(
      `SELECT status, closeOn, capacityLimit
             , (SELECT COUNT(*) FROM Responses WHERE eventId = ?) AS responseCount
         FROM Events
        WHERE eventId = ?`,
      [eventId, eventId]
    );
    if (!event) return res.status(404).json({ error: 'Event not found' });

    // Must be OPEN (routes layer also checks, but keep this safeguard)
    if (String(event.status || '').toLowerCase() !== 'open') {
      return res.status(403).json({ error: 'Event is not accepting responses' });
    }
    if (event.closeOn && new Date(event.closeOn) <= new Date()) {
      return res.status(403).json({ error: 'Form closed' });
    }
    if (event.capacityLimit && event.responseCount >= event.capacityLimit) {
      return res.status(403).json({ error: 'Capacity reached' });
    }

    // 2) Normalize payload (support both old flat fields and new {participant, answers})
    const body = req.body || {};
    const p = body.participant || body; // fallback to old shape

    const participant = {
      firstName:   p.firstName?.trim() || '',
      lastName:    p.lastName?.trim()  || '',
      email:       p.email?.trim()     || '',
      phone:       p.phone?.trim()     || '',
      homeNumber:  p.homeNumber?.trim() || '',
      street:      p.street?.trim()     || '',
      apartment:   p.apartment?.trim()  || null,
      city:        p.city?.trim()       || '',
      state:       p.state?.trim()      || '',
      zipcode:     p.zipcode?.trim()    || '',
    };

    if (!participant.firstName || !participant.lastName || !participant.email ||
        !participant.phone || !participant.homeNumber || !participant.street ||
        !participant.city || !participant.state || !participant.zipcode) {
      return res.status(400).json({ error: 'Missing required participant fields' });
    }

    const answers = Array.isArray(body.answers) ? body.answers : [];

    // 3) Persist
    await conn.beginTransaction();
    const participantId = await service.findOrCreateParticipant(conn, participant);
    const submissionId  = await service.insertResponse(conn, eventId, participantId);
    await service.batchInsertAnswers(conn, submissionId, answers);
    await conn.commit();

    // 4) Optional email
    if (event.emailConfirmation && participant.email) {
      emailService.sendResponseEmail(participant.email, { eventId, submissionId })
        .catch(err => console.error('Email send failed:', err.message));
    }

    return res.status(201).json({ submissionId });
  } catch (err) {
    try { await conn.rollback(); } catch (_) {}
    next(err);
  } finally {
    conn.release();
  }
};