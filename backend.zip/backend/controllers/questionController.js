/**
 * questionController.js
 * Handlers for Questions CRUD.
 */
const pool = require('../db');

exports.listQuestions = async (req, res, next) => {
  try {
    const eventId = +req.params.eventId;
    const [rows] = await pool.query(
      'SELECT * FROM Questions WHERE eventId = ? ORDER BY questionId',
      [eventId]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
};

exports.createQuestion = async (req, res, next) => {
  try {
    const eventId = +req.params.eventId;
    const { questionText, questionType, isRequired = false } = req.body;
    const [result] = await pool.query(
      `INSERT INTO Questions
         (eventId,questionText,questionType,isRequired)
       VALUES (?,?,?,?)`,
      [eventId, questionText, questionType, isRequired]
    );
    res.status(201).json({ questionId: result.insertId });
  } catch (err) {
    next(err);
  }
};

exports.updateQuestion = async (req, res, next) => {
  try {
    const eventId    = +req.params.eventId;
    const questionId = +req.params.questionId;
    const { questionText, questionType, isRequired } = req.body;
    const [r] = await pool.query(
        `UPDATE Questions
           SET
             questionText = COALESCE(?, questionText),
             questionType = COALESCE(?, questionType),
             isRequired   = COALESCE(?, isRequired)
         WHERE questionId = ? AND eventId = ?`,
        [questionText, questionType, isRequired, questionId, eventId]
    );
    if (!r.affectedRows) return res.status(404).json({ error: 'Question not found' });
    res.json({ updated: r.affectedRows });
  } catch (err) {
    next(err);
  }
};

exports.deleteQuestion = async (req, res, next) => {
  try {
    const eventId    = +req.params.eventId;
    const questionId = +req.params.questionId;
    const [r] = await pool.query(
      'DELETE FROM Questions WHERE questionId=? AND eventId=?',
      [questionId, eventId]
    );
    if (!r.affectedRows) return res.status(404).json({ error: 'Question not found' });
    res.json({ deleted: r.affectedRows });
  } catch (err) {
    next(err);
  }
};

async function checkEventOpen(eventId) {
  const [event] = await pool.query(
    'SELECT isPublished, closeOn FROM Events WHERE eventId = ?',
    [eventId]
  );
  
  if (!event.length) {
    const err = new Error('Event not found');
    err.status = 404;
    throw err;
  }
  
  if (event[0].isPublished !== 'public') {
    const err = new Error('Event is not published');
    err.status = 403;
    throw err;
  }
  
  if (event[0].closeOn && new Date(event[0].closeOn) < new Date()) {
    const err = new Error('Event submissions are closed');
    err.status = 403;
    throw err;
  }
}

exports.checkEventOpen = checkEventOpen;

// Modify listResponses to include check
exports.listResponses = async (req, res, next) => {
  try {
    const eventId = +req.params.eventId;
    await checkEventOpen(eventId);
    
    // ... rest of the existing method
  } catch (err) {
    next(err);
  }
};
