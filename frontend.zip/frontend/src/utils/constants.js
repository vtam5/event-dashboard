export const SORT_OPTIONS = [
    { value: 'alpha', label: 'Alphabetical' },
    { value: 'eventDate', label: 'Event Date' },
    { value: 'created', label: 'Created' },
    { value: 'custom', label: 'Custom' }
  ]
  
  export const QUESTION_TYPES = [
    { value: 'text', label: 'Short Text' }
    // extend: radio, checkbox, dropdown, file, rating...
  ]
  