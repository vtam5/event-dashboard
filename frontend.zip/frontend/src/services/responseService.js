// frontend/src/services/responseService.js
import api from './api'
import { savedResponse } from '../hooks/useSavedResponse'

// ------- CRUD (admin list optional) -------
export const listResponses = (eventId, { admin = false } = {}) =>
  api.get(`/api/events/${eventId}/responses`, { params: admin ? { admin: 1 } : undefined })
     .then(r => r.data)

// Create → stores { submissionId, editToken } for this event
export const createResponse = async (eventId, payload) => {
  const { data } = await api.post(`/api/events/${eventId}/responses`, payload);
  if (data && data.submissionId && data.editToken) {
    savedResponse.set(eventId, {
      submissionId: data.submissionId,
      editToken: data.editToken,
      savedAt: Date.now(),
    });
  }
  return data;
};

// Update → uses x-edit-token automatically if not admin
export const updateResponse = async (eventId, responseId, payload, { admin = false, token } = {}) => {
  const headers = {};
  const params = admin ? { admin: 1 } : undefined;
  if (!admin) {
    const t = token || savedResponse.get(eventId)?.editToken;
    if (t) headers['x-edit-token'] = t;
  }
  const { data } = await api.put(`/api/events/${eventId}/responses/${responseId}`, payload, { headers, params });
  return data;
};

// Delete → uses x-edit-token automatically if not admin
export const deleteResponse = async (eventId, responseId, { admin = false, token } = {}) => {
  const headers = {};
  const params = admin ? { admin: 1 } : undefined;
  if (!admin) {
    const t = token || savedResponse.get(eventId)?.editToken;
    if (t) headers['x-edit-token'] = t;
  }
  const { data } = await api.delete(`/api/events/${eventId}/responses/${responseId}`, { headers, params });
  if (data?.success && !admin) {
    savedResponse.clear(eventId);
  }
  return data;
};
